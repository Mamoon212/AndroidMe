package com.mo2a.example.androidme;

import android.support.v4.app.Fragment;

public class BodyPartFragment extends Fragment {
   
}
